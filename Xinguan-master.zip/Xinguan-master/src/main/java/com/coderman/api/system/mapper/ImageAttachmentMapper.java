package com.coderman.api.system.mapper;

import com.coderman.api.common.pojo.system.ImageAttachment;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author zhangyukang
 * @Date 2020/4/25 10:17
 * @Version 1.0
 **/
public interface ImageAttachmentMapper extends Mapper<ImageAttachment> {

}
