package com.coderman.api.biz.mapper;

import com.coderman.api.common.pojo.biz.Consumer;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author zhangyukang
 * @Date 2020/4/5 09:55
 * @Version 1.0
 **/
public interface ConsumerMapper extends Mapper<Consumer> {
}
