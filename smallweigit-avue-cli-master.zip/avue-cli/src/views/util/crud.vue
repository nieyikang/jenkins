<template>
  <basic-container>
    <avue-crud v-bind="bindVal"
               v-on="onEvent"
               :page.sync="page"
               v-model="form">
    </avue-crud>
  </basic-container>
</template>

<script>
export default window.$crudCommon({}, {
  name: 'crud/index'
})
</script>

<style lang="scss" scoped>
</style>