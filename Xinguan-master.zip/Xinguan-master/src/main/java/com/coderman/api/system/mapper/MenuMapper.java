package com.coderman.api.system.mapper;

import com.coderman.api.common.pojo.system.Menu;
import tk.mybatis.mapper.common.BaseMapper;

/**
 * @Author zhangyukang
 * @Date 2020/3/7 16:11
 * @Version 1.0
 **/
public interface MenuMapper extends BaseMapper<Menu> {
}
