package com.coderman.api.biz.mapper;

import com.coderman.api.common.pojo.biz.InStockInfo;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author zhangyukang
 * @Date 2020/3/20 15:46
 * @Version 1.0
 **/
public interface InStockInfoMapper extends Mapper<InStockInfo> {
}
