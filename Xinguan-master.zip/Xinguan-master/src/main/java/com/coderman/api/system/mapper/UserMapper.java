package com.coderman.api.system.mapper;

import com.coderman.api.common.pojo.system.User;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author zhangyukang
 * @Date 2020/3/7 15:03
 * @Version 1.0
 **/
public interface UserMapper extends Mapper<User> {
}
