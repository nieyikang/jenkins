package com.coderman.api.biz.mapper;

import com.coderman.api.common.pojo.biz.OutStock;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author zhangyukang
 * @Date 2020/3/19 09:53
 * @Version 1.0
 **/
public interface OutStockMapper extends Mapper<OutStock> {
}
