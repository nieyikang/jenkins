# drf_rest_rbac

#### 介绍1
后端技术：Python3.6 Django2.1 django rest framework + jwt

前端技术：vue + elementUI  原项目地址[elunez大佬开源的项目](https://github.com/elunez/eladmin-qd)

新手学习drf的第一个项目，完整前后端权限控制，前端权限实现到按钮级，后端根据判断路由地址是否在请求的url内，再判断是否该用户是否有权限，权限控制还有些问题，后续有时间再优化。

#### 安装教程

#### 1. 前端(eladmin-qd)安装
安装依赖

npm install

启动服务 localhost:8013

npm run dev

构建生产环境

npm run build

#### 2. 后端(rest_xops)启动
安装模块

pip install -r requirements.txt

创建数据库rest_xops

python manage.py makemigrations rbac
python manage.py migrate

导入实例数据

python manage.py loaddata rbac_data.json

修改超级管理员的密码

python manage.py changepassword admin
