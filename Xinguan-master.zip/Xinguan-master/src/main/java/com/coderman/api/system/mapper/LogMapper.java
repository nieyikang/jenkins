package com.coderman.api.system.mapper;

import com.coderman.api.common.pojo.system.Log;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author zhangyukang
 * @Date 2020/4/2 20:27
 * @Version 1.0
 **/
public interface LogMapper extends Mapper<Log> {
}
