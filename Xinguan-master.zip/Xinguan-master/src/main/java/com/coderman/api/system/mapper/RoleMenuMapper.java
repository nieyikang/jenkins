package com.coderman.api.system.mapper;

import com.coderman.api.common.pojo.system.RoleMenu;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author zhangyukang
 * @Date 2020/3/7 16:06
 * @Version 1.0
 **/
public interface RoleMenuMapper extends Mapper<RoleMenu> {
}
