import request from '@/utils/request'

// 获取所有的Role
export function getRoleAll() {
  return request({
    url: 'api/role/all/',
    method: 'get'
  })
}

export function add(data) {
  return request({
    url: 'api/roles/',
    method: 'post',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/roles/' + id + '/',
    method: 'delete'
  })
}

export function edit(id, data) {
  return request({
    url: 'api/roles/' + id + '/',
    method: 'put',
    data
  })
}
