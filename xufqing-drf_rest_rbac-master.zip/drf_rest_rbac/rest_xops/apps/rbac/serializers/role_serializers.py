# @Time    : 2019/1/14 15:11
# @Author  : xufqing

from rest_framework import serializers
from ..models import Role

class RoleListSerializer(serializers.ModelSerializer):
    '''
    角色序列化
    '''
    class Meta:
        model = Role
        fields = '__all__'
        depth = 1

class RoleModifySerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = '__all__'

class AllRoleSerializer(serializers.ModelSerializer):
    '''
    所有角色树序列化
    '''
    label = serializers.StringRelatedField(source='name')
    class Meta:
        model = Role
        fields = ['id','label']