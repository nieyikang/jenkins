package com.coderman.api.system.mapper;

import com.coderman.api.common.pojo.system.Department;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author zhangyukang
 * @Date 2020/3/15 14:15
 * @Version 1.0
 **/
public interface DepartmentMapper extends Mapper<Department> {

}
