package com.coderman.api.biz.mapper;

import com.coderman.api.common.pojo.biz.OutStockInfo;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author zhangyukang
 * @Date 2020/5/25 11:11
 * @Version 1.0
 **/
public interface OutStockInfoMapper extends Mapper<OutStockInfo> {
}
